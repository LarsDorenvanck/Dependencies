# GENERATED VERSION FILE
# TIME: Sun Jul 21 23:55:01 2024

__version__ = '0.5.0+be2ecb8'
short_version = '0.5.0'
