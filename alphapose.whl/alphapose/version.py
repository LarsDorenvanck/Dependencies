# GENERATED VERSION FILE
# TIME: Fri Feb  9 17:35:43 2024

__version__ = '0.5.0+'
short_version = '0.5.0'
